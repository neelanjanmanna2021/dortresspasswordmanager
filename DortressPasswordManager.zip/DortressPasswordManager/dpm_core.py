"""
Dortress Password Manager - vault engine
(c) Dortress Technologies Private Limited

Vault file format (.dpm, any name, any location)
-----------------------------------------------
header (59 bytes, authenticated as AAD, not secret):
    magic "DTPM" | version u8 | key mode u8 | argon2 t u32 | argon2 m_kib u32 |
    argon2 lanes u8 | salt 32 bytes | nonce 12 bytes
body:
    AES-256-GCM( JSON vault, padded to a multiple of 4 KiB )

Master key
----------
* Password mode : secret = the password (Unicode NFC)
* Key-file mode : secret = lowercase hex SHA-512 of ANY file (128 chars).
                  Typing/pasting that hex string works exactly like the file.
* Both          : secret = sha512_hex + "\\n" + password
key = Argon2id(secret, salt, t=3, m=128 MiB, p=4) -> 256-bit AES-GCM key.
Every save uses a fresh random 96-bit nonce; a new salt is generated whenever
the master key changes.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import secrets
import shutil
import string
import struct
import sys
import time
import unicodedata
import uuid
from pathlib import Path
from typing import Callable, Optional

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.argon2 import Argon2id

APP_NAME = "Dortress Password Manager"
VERSION = "1.0.0"
DEVELOPER = "Dortress Technologies Private Limited"

EXT = ".dpm"
MAGIC = b"DTPM"
FORMAT_VERSION = 1
HEADER_FMT = ">4sBBIIB32s12s"
HEADER_LEN = struct.calcsize(HEADER_FMT)
PAD_BLOCK = 4096

MODE_PASSWORD = 1
MODE_KEYFILE = 2
MODE_BOTH = 3
MODE_NAMES = {MODE_PASSWORD: "Password", MODE_KEYFILE: "Key file (SHA-512)",
              MODE_BOTH: "Password + key file"}

DEFAULT_KDF = {"t": 3, "m_kib": 131072, "p": 4}       # 128 MiB
KDF_LIMITS = {"t": (1, 64), "m_kib": (8192, 4194304), "p": (1, 64)}

HISTORY_KEEP = 10
ENTRY_FIELDS = ("title", "username", "password", "url", "notes", "folder")


class VaultError(Exception):
    pass


class WrongKey(VaultError):
    pass


def needs_password(mode: int) -> bool:
    return mode in (MODE_PASSWORD, MODE_BOTH)


def needs_keyfile(mode: int) -> bool:
    return mode in (MODE_KEYFILE, MODE_BOTH)


# --------------------------------------------------------------------------
# Master secret
# --------------------------------------------------------------------------
def sha512_file(path, progress: Optional[Callable[[int, int], None]] = None) -> str:
    """Lowercase hex SHA-512 of any file (streamed, works for huge files)."""
    h = hashlib.sha512()
    total = os.path.getsize(path)
    done = 0
    with open(path, "rb") as f:
        while True:
            b = f.read(4 * 1024 * 1024)
            if not b:
                break
            h.update(b)
            done += len(b)
            if progress:
                progress(done, total)
    return h.hexdigest()


def normalize_hash(text: str) -> str:
    """Accept a pasted SHA-512 hex digest (spaces/case/newlines tolerated)."""
    s = "".join(text.split()).lower()
    if len(s) != 128 or any(c not in string.hexdigits.lower() for c in s):
        raise VaultError("A SHA-512 hash must be exactly 128 hexadecimal characters.")
    return s


def generate_keyfile(path, size: int = 4096) -> str:
    """Write a new random key file and return its SHA-512 hex."""
    data = os.urandom(size)
    p = Path(path)
    with open(p, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    return hashlib.sha512(data).hexdigest()


def build_secret(mode: int, password: Optional[str] = None, keyhash: Optional[str] = None) -> bytes:
    if needs_password(mode) and not password:
        raise VaultError("Master password is required.")
    if needs_keyfile(mode) and not keyhash:
        raise VaultError("Key file (or its SHA-512 hash) is required.")
    pw = unicodedata.normalize("NFC", password or "")
    if mode == MODE_PASSWORD:
        return pw.encode("utf-8")
    kh = normalize_hash(keyhash)
    if mode == MODE_KEYFILE:
        return kh.encode("ascii")
    if mode == MODE_BOTH:
        return (kh + "\n" + pw).encode("utf-8")
    raise VaultError(f"Unknown key mode {mode}")


def derive_key(secret: bytes, salt: bytes, kdf: dict) -> bytes:
    return Argon2id(salt=salt, length=32, iterations=kdf["t"], lanes=kdf["p"],
                    memory_cost=kdf["m_kib"]).derive(secret)


# --------------------------------------------------------------------------
# Vault
# --------------------------------------------------------------------------
def read_header(path) -> dict:
    with open(path, "rb") as f:
        raw = f.read(HEADER_LEN)
    if len(raw) != HEADER_LEN:
        raise VaultError("This is not a Dortress vault (file too short).")
    magic, ver, mode, t, m, p, salt, nonce = struct.unpack(HEADER_FMT, raw)
    if magic != MAGIC:
        raise VaultError("This is not a Dortress Password Manager vault.")
    if ver != FORMAT_VERSION:
        raise VaultError(f"Unsupported vault version {ver}.")
    if mode not in MODE_NAMES:
        raise VaultError("Corrupt vault header (key mode).")
    kdf = {"t": t, "m_kib": m, "p": p}
    for k, (lo, hi) in KDF_LIMITS.items():
        if not lo <= kdf[k] <= hi:
            raise VaultError("Corrupt or unsafe vault header (KDF parameters).")
    return {"raw": raw, "mode": mode, "kdf": kdf, "salt": salt, "nonce": nonce}


def _now() -> float:
    return round(time.time(), 3)


class Vault:
    def __init__(self, path, key: bytes, salt: bytes, kdf: dict, mode: int, data: dict):
        self.path = Path(path)
        self._key = key
        self.salt = salt
        self.kdf = dict(kdf)
        self.mode = mode
        self.data = data
        self.data.setdefault("entries", [])
        self.data.setdefault("settings", {"autolock_min": 5, "clip_seconds": 20})

    # ------------------------------------------------------------ create/open
    @classmethod
    def create(cls, path, mode: int, password: Optional[str] = None,
               keyhash: Optional[str] = None, name: Optional[str] = None,
               kdf: Optional[dict] = None) -> "Vault":
        kdf = dict(kdf or DEFAULT_KDF)
        salt = os.urandom(32)
        key = derive_key(build_secret(mode, password, keyhash), salt, kdf)
        data = {"format": "dortress-password-vault", "name": name or Path(path).stem,
                "created": _now(), "modified": _now(), "entries": [],
                "settings": {"autolock_min": 5, "clip_seconds": 20}}
        v = cls(path, key, salt, kdf, mode, data)
        v.save()
        return v

    @classmethod
    def open(cls, path, password: Optional[str] = None, keyhash: Optional[str] = None) -> "Vault":
        hdr = read_header(path)
        key = derive_key(build_secret(hdr["mode"], password, keyhash), hdr["salt"], hdr["kdf"])
        with open(path, "rb") as f:
            blob = f.read()
        try:
            pt = AESGCM(key).decrypt(hdr["nonce"], blob[HEADER_LEN:], hdr["raw"])
        except InvalidTag:
            raise WrongKey("Wrong master key, or the vault file is damaged.") from None
        try:
            data = json.loads(pt.decode("utf-8"))
        except Exception:
            raise VaultError("Vault decrypted but its contents are corrupt.") from None
        return cls(path, key, hdr["salt"], hdr["kdf"], hdr["mode"], data)

    # --------------------------------------------------------------- saving
    def _serialize(self) -> tuple[bytes, bytes]:
        nonce = os.urandom(12)
        header = struct.pack(HEADER_FMT, MAGIC, FORMAT_VERSION, self.mode, self.kdf["t"],
                             self.kdf["m_kib"], self.kdf["p"], self.salt, nonce)
        body = json.dumps(self.data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        body += b" " * (-len(body) % PAD_BLOCK)  # hide exact size; JSON ignores trailing spaces
        return header, AESGCM(self._key).encrypt(nonce, body, header)

    def save(self, path=None) -> Path:
        """Atomic save. Keeps the previous version as <name>.bak. path = 'Save as'."""
        target = Path(path) if path else self.path
        self.data["modified"] = _now()
        header, ct = self._serialize()
        target.parent.mkdir(parents=True, exist_ok=True)
        tmp = target.with_name(target.name + ".tmp")
        with open(tmp, "wb") as f:
            f.write(header)
            f.write(ct)
            f.flush()
            os.fsync(f.fileno())
        if target.exists():
            try:
                shutil.copyfile(target, target.with_name(target.name + ".bak"))
            except OSError:
                pass
        os.replace(tmp, target)
        self.path = target
        return target

    def change_master(self, mode: int, password: Optional[str] = None,
                      keyhash: Optional[str] = None) -> None:
        salt = os.urandom(32)
        key = derive_key(build_secret(mode, password, keyhash), salt, self.kdf)
        old = (self._key, self.salt, self.mode)
        self._key, self.salt, self.mode = key, salt, mode
        try:
            self.save()
        except Exception:
            self._key, self.salt, self.mode = old
            raise

    def lock(self) -> None:
        self._key = b""
        self.data = {}

    # -------------------------------------------------------------- entries
    @property
    def name(self) -> str:
        return self.data.get("name") or self.path.stem

    @property
    def entries(self) -> list:
        return self.data["entries"]

    @property
    def settings(self) -> dict:
        return self.data["settings"]

    def get(self, eid: str) -> Optional[dict]:
        for e in self.entries:
            if e["id"] == eid:
                return e
        return None

    def folders(self) -> list:
        return sorted({e.get("folder", "").strip() for e in self.entries if e.get("folder", "").strip()},
                      key=str.lower)

    def add_entry(self, fields: dict) -> str:
        e = {k: str(fields.get(k, "") or "") for k in ENTRY_FIELDS}
        e.update(id=uuid.uuid4().hex, created=_now(), modified=_now(), history=[])
        self.entries.append(e)
        return e["id"]

    def update_entry(self, eid: str, fields: dict) -> None:
        e = self.get(eid)
        if e is None:
            raise VaultError("Entry not found.")
        new_pw = str(fields.get("password", e["password"]) or "")
        if e.get("password") and new_pw != e["password"]:
            e.setdefault("history", []).insert(0, {"password": e["password"], "changed": _now()})
            del e["history"][HISTORY_KEEP:]
        for k in ENTRY_FIELDS:
            if k in fields:
                e[k] = str(fields[k] or "")
        e["modified"] = _now()

    def delete_entry(self, eid: str) -> None:
        self.data["entries"] = [e for e in self.entries if e["id"] != eid]

    def search(self, text: str = "", folder: Optional[str] = None) -> list:
        q = text.strip().lower()
        out = []
        for e in self.entries:
            if folder and e.get("folder", "").strip() != folder:
                continue
            if q and not any(q in str(e.get(k, "")).lower()
                             for k in ("title", "username", "url", "notes", "folder")):
                continue
            out.append(e)
        return out


# --------------------------------------------------------------------------
# Passwords: generator & strength
# --------------------------------------------------------------------------
SYMBOLS = "!@#$%^&*()-_=+[]{};:,.?/<>~|"
AMBIGUOUS = set("Il1O0o|`'\"")


def generate_password(length: int = 24, upper=True, lower=True, digits=True, symbols=True,
                      avoid_ambiguous=False) -> str:
    sets = []
    if upper:
        sets.append(string.ascii_uppercase)
    if lower:
        sets.append(string.ascii_lowercase)
    if digits:
        sets.append(string.digits)
    if symbols:
        sets.append(SYMBOLS)
    if not sets:
        sets = [string.ascii_lowercase]
    if avoid_ambiguous:
        sets = ["".join(c for c in s if c not in AMBIGUOUS) for s in sets]
    length = max(length, len(sets))
    chars = [secrets.choice(s) for s in sets]               # at least one of each set
    pool = "".join(sets)
    chars += [secrets.choice(pool) for _ in range(length - len(chars))]
    secrets.SystemRandom().shuffle(chars)
    return "".join(chars)


def generate_dortress() -> str:
    """Dortress policy: 10 digits, 3 upper, 3 lower, 4 special (20 chars)."""
    chars = ([secrets.choice(string.digits) for _ in range(10)]
             + [secrets.choice(string.ascii_uppercase) for _ in range(3)]
             + [secrets.choice(string.ascii_lowercase) for _ in range(3)]
             + [secrets.choice(SYMBOLS) for _ in range(4)])
    secrets.SystemRandom().shuffle(chars)
    return "".join(chars)


def generated_entropy(length, upper, lower, digits, symbols, avoid_ambiguous=False) -> float:
    pool = (26 if upper else 0) + (26 if lower else 0) + (10 if digits else 0) + \
           (len(SYMBOLS) if symbols else 0)
    if avoid_ambiguous:
        pool -= 8
    return length * math.log2(max(pool, 2))


def password_strength(pw: str) -> tuple[int, str, float]:
    """(score 0-100, label, estimated bits) for human-chosen passwords."""
    if not pw:
        return 0, "Empty", 0.0
    pool = 0
    if any(c.islower() for c in pw):
        pool += 26
    if any(c.isupper() for c in pw):
        pool += 26
    if any(c.isdigit() for c in pw):
        pool += 10
    if any(not c.isalnum() for c in pw):
        pool += 32
    bits = len(pw) * math.log2(max(pool, 2))
    bits *= 0.55 + 0.45 * (len(set(pw)) / len(pw))
    bits -= 4 * sum(1 for a, b, c in zip(pw, pw[1:], pw[2:])
                    if ord(b) - ord(a) == 1 and ord(c) - ord(b) == 1)
    low = pw.lower()
    for bad in ("password", "qwerty", "admin", "dortress", "123456", "letmein", "welcome", "iloveyou"):
        if bad in low:
            bits -= 25
    bits = max(bits, 0.0)
    score = int(min(100, bits / 1.3))
    label = ("Very weak" if score < 20 else "Weak" if score < 40 else "Fair" if score < 60
             else "Strong" if score < 80 else "Fortress-grade")
    return score, label, bits


# --------------------------------------------------------------------------
# Portable settings (stored next to the program, never in AppData)
# --------------------------------------------------------------------------
def app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


class Settings:
    MAX_RECENT = 8

    def __init__(self, path: Optional[Path] = None):
        self.path = Path(path) if path else app_dir() / "dortress_pm_settings.json"
        self.data = {"recent": [], "remember_recent": True}
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                self.data.update(json.load(f))
        except Exception:
            pass

    def save(self) -> None:
        try:
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=2)
        except OSError:
            pass  # read-only media: stay portable, just don't remember

    @property
    def recent(self) -> list:
        return [p for p in self.data.get("recent", []) if isinstance(p, str)]

    def add_recent(self, path) -> None:
        if not self.data.get("remember_recent", True):
            return
        p = str(Path(path).resolve())
        rec = [r for r in self.recent if os.path.normcase(r) != os.path.normcase(p)]
        self.data["recent"] = [p] + rec[: self.MAX_RECENT - 1]
        self.save()

    def remove_recent(self, path) -> None:
        self.data["recent"] = [r for r in self.recent if r != path]
        self.save()


def human_bytes(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{int(n)} B" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"
