# Dortress Password Manager v1.0.0
**Developed by Dortress Technologies Private Limited**

A portable, black & gold password manager. One vault file, encrypted at rest with AES-256-GCM.

## Run
- **Windows:** install Python 3.10+ (tick "Add Python to PATH"), then double-click `run_windows.bat`.
- **Single portable .exe:** run `build_exe.bat`, then copy `dist\DortressPasswordManager.exe`
  and your vault to a USB stick. No installer, nothing written to AppData or the registry.
  The only extra file is `dortress_pm_settings.json` (recent vaults list), stored next to the app.

## Master key: three choices
| Mode | What unlocks the vault |
|---|---|
| Password | A master password (recommended: 10 numbers, 3 upper, 3 lower, 4 special) |
| Key file | The SHA-512 hash of **any** file you pick: photo, PDF, or a generated random `.key` |
| Password + key file | Both. An attacker needs the file **and** the password. Strongest. |

In key-file mode the secret is the file's lowercase hex SHA-512. You can also paste that hash
instead of choosing the file, e.g. from `certutil -hashfile yourfile SHA512` (spaces are fine).

**Key file warning:** if the file changes by even one byte (photo apps often rewrite metadata),
or is lost, the vault cannot be opened. Keep copies and never edit it.

## Custom location & name
Create the vault anywhere, with any name (e.g. `E:\Private\Office Keys.dpm`).
**Save as…** writes a copy anywhere else and continues working on that copy.
Every save is atomic and keeps the previous version as `<name>.bak`.

## Cryptography
- AES-256-GCM over the whole vault; the header (mode, KDF settings, salt, nonce) is authenticated as AAD
- Argon2id: 128 MiB memory, 3 iterations, 4 lanes; new 256-bit salt whenever the master key changes
- Fresh random 96-bit nonce on every save; contents padded to 4 KiB blocks to hide entry count
- Unicode passwords normalised (NFC), so the same password works on every computer
- Tampered, truncated or wrong-key vaults are rejected; absurd KDF settings in a header are refused

## Features
Entries (title, username, password, website, folder, notes), search, folder filter, sorting,
password generator (8-128 chars, character sets, avoid look-alikes, Dortress 10·3·3·4 preset),
strength meter, 10-deep password history, copy with auto-clearing clipboard,
auto-lock after inactivity, increasing delay after wrong attempts, change master key,
and a layout that adapts to any window size.

Shortcuts: Ctrl+N new · Ctrl+F search · Ctrl+L lock · in the list: Enter edit,
Ctrl+C copy password, Ctrl+B copy username, Ctrl+U open website, Delete remove.

## Honest limits
- Python cannot reliably wipe secrets from RAM. Lock the vault and shut down rather than sleep.
- Windows clipboard history (Win+V) and cloud clipboard can keep copies. Turn them off.
- No browser autofill or sync; the vault is one file you carry or back up yourself.
- Not independently audited yet.
