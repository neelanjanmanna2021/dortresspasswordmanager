@echo off
cd /d "%~dp0"
python -m pip install --upgrade -r requirements.txt pyinstaller
python -m PyInstaller --noconfirm --onefile --windowed --name "DortressPasswordManager" dortress_password_manager.py
echo.
echo Built: dist\DortressPasswordManager.exe
echo Copy that single .exe (and your .dpm vault) to a USB stick to carry it anywhere.
pause
