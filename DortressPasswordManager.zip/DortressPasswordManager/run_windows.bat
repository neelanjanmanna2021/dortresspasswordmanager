@echo off
title Dortress Password Manager
cd /d "%~dp0"
python -m pip install --upgrade -r requirements.txt
start "" pythonw dortress_password_manager.py %*
