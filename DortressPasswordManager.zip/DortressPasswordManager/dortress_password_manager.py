"""
Dortress Password Manager - portable black & gold GUI
(c) Dortress Technologies Private Limited

Run:  python dortress_password_manager.py  [optional path to a vault]
"""
from __future__ import annotations

import math
import os
import queue
import sys
import threading
import time
import tkinter as tk
import webbrowser
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import dpm_core as core

# ----------------------------------------------------------------- theme ----
BG = "#050507"
PANEL = "#0d0d12"
PANEL2 = "#15151c"
PANEL3 = "#221d0e"
LINE = "#2c2615"
GOLD = "#d4af37"
GOLD_HI = "#f6dc84"
GOLD_DIM = "#7d6420"
TEXT = "#ece6d2"
MUTED = "#8f897a"
RED = "#e5534b"
AMBER = "#e0a030"
GREEN = "#43c27a"

WIN = sys.platform.startswith("win")
FONT = "Segoe UI" if WIN else "Helvetica"
FONT_B = "Segoe UI Semibold" if WIN else "Helvetica"
MONO = "Consolas" if WIN else "Courier"
VAULT_TYPES = [("Dortress vault", "*" + core.EXT), ("All files", "*.*")]


def lerp_color(a: str, b: str, t: float) -> str:
    t = max(0.0, min(1.0, t))
    ca = [int(a[i:i + 2], 16) for i in (1, 3, 5)]
    cb = [int(b[i:i + 2], 16) for i in (1, 3, 5)]
    return "#%02x%02x%02x" % tuple(int(x + (y - x) * t) for x, y in zip(ca, cb))


def alive(w) -> bool:
    try:
        return bool(w is not None and w.winfo_exists())
    except Exception:
        return False


def fmt_time(ts) -> str:
    try:
        return datetime.fromtimestamp(float(ts)).strftime("%d %b %Y, %H:%M")
    except Exception:
        return "—"


# --------------------------------------------------------------- widgets ----
class GButton(tk.Button):
    """Native button (reliable click + keyboard), styled black & gold."""
    STYLES = {"primary": (GOLD, "#0a0a0a", GOLD_HI),
              "ghost": (PANEL2, GOLD, PANEL3),
              "danger": ("#2a110f", RED, "#3d1814")}

    def __init__(self, master, text, command=None, kind="primary", size=10, padx=14, pady=6, **kw):
        bg, fg, hover = self.STYLES[kind]
        super().__init__(master, text=text, command=command, bg=bg, fg=fg, activebackground=hover,
                         activeforeground=fg, disabledforeground=MUTED, relief="flat", bd=0,
                         overrelief="flat", highlightthickness=1, highlightbackground=GOLD_DIM,
                         highlightcolor=GOLD_HI, font=(FONT_B, size), padx=padx, pady=pady,
                         cursor="hand2", takefocus=1, **kw)
        self._bg, self._hover = bg, hover
        self.bind("<Enter>", lambda e: str(self["state"]) != "disabled" and self.config(bg=self._hover), add="+")
        self.bind("<Leave>", lambda e: self.config(bg=self._bg), add="+")
        self.bind("<Return>", lambda e: self.invoke(), add="+")

    def set_enabled(self, on: bool):
        self.config(state="normal" if on else "disabled", cursor="hand2" if on else "arrow", bg=self._bg)


class ScrollFrame(tk.Frame):
    """Vertically scrollable area whose content always matches the width."""

    def __init__(self, master, bg=BG):
        super().__init__(master, bg=bg)
        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0, bd=0)
        self.vsb = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview,
                                 style="Gold.Vertical.TScrollbar")
        self.inner = tk.Frame(self.canvas, bg=bg)
        self.win = self.canvas.create_window(0, 0, window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.vsb.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.vsb.pack(side="right", fill="y")
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self.win, width=e.width))

    def wheel(self, steps: int):
        try:
            if self.inner.winfo_height() > self.canvas.winfo_height():
                self.canvas.yview_scroll(steps, "units")
        except (tk.TclError, TypeError):
            pass

    def to_top(self):
        self.canvas.yview_moveto(0)


class FlowGrid(tk.Frame):
    """Children reflow into as many columns as the width allows."""

    def __init__(self, master, min_w=240, gap=12, bg=None):
        super().__init__(master, bg=bg or master.cget("bg"))
        self.min_w, self.gap, self.items, self.cols = min_w, gap, [], 0
        self.bind("<Configure>", self._resize)

    def add(self, w):
        self.items.append(w)
        self._layout(max(1, self.cols or 1))
        return w

    def _resize(self, e):
        cols = max(1, min(len(self.items) or 1, (e.width + self.gap) // (self.min_w + self.gap)))
        if cols != self.cols:
            self._layout(cols)

    def _layout(self, cols):
        self.cols = cols
        for c in range(max(len(self.items), 1)):
            self.columnconfigure(c, weight=1 if c < cols else 0, uniform="f" if c < cols else "")
        for i, w in enumerate(self.items):
            r, c = divmod(i, cols)
            w.grid(row=r, column=c, sticky="nsew", padx=(0 if c == 0 else self.gap, 0),
                   pady=(0 if r == 0 else self.gap, 0))


def wlabel(parent, text, fg=TEXT, font=None, **pack):
    """Label that wraps to the available width."""
    lb = tk.Label(parent, text=text, bg=parent.cget("bg"), fg=fg, font=font or (FONT, 10),
                  justify="left", anchor="w")
    lb.bind("<Configure>", lambda e: lb.config(wraplength=max(60, e.width - 4)))
    lb.pack(fill="x", **pack)
    return lb


def card(parent, title=None, accent=GOLD):
    outer = tk.Frame(parent, bg=PANEL, highlightthickness=1, highlightbackground=LINE)
    tk.Frame(outer, bg=accent, height=2).pack(fill="x")
    inner = tk.Frame(outer, bg=PANEL)
    inner.pack(fill="both", expand=True, padx=16, pady=14)
    if title:
        tk.Label(inner, text=title.upper(), bg=PANEL, fg=GOLD, font=(FONT_B, 9), anchor="w").pack(
            fill="x", pady=(0, 8))
    return outer, inner


def flabel(parent, text):
    tk.Label(parent, text=text, bg=parent.cget("bg"), fg=TEXT, font=(FONT_B, 9), anchor="w").pack(
        fill="x", pady=(10, 4))


def gentry(parent, value="", mono=False):
    fr = tk.Frame(parent, bg=PANEL2, highlightthickness=1, highlightbackground=LINE, highlightcolor=GOLD)
    e = tk.Entry(fr, bd=0, relief="flat", bg=PANEL2, fg=TEXT, insertbackground=GOLD,
                 font=(MONO, 12) if mono else (FONT, 11))
    e.pack(fill="x", padx=10, pady=7)
    e.insert(0, value)
    e.bind("<FocusIn>", lambda ev: fr.config(highlightbackground=GOLD))
    e.bind("<FocusOut>", lambda ev: fr.config(highlightbackground=LINE))
    fr.pack(fill="x")
    return e


class PasswordEntry(tk.Frame):
    """Masked (*) field with SHOW/HIDE."""

    def __init__(self, master, on_change=None, value=""):
        super().__init__(master, bg=PANEL2, highlightthickness=1, highlightbackground=LINE,
                         highlightcolor=GOLD)
        self.var = tk.StringVar(value=value)
        self.entry = tk.Entry(self, textvariable=self.var, show="*", width=20, bd=0, bg=PANEL2,
                              fg=GOLD_HI, insertbackground=GOLD, font=(MONO, 13), relief="flat")
        self.entry.pack(side="left", fill="x", expand=True, padx=(10, 4), pady=7)
        self.eye = tk.Button(self, text="SHOW", command=self.toggle, bg=PANEL2, fg=MUTED,
                             activebackground=PANEL3, activeforeground=GOLD, relief="flat", bd=0,
                             font=(FONT_B, 8), cursor="hand2", padx=10, highlightthickness=0)
        self.eye.pack(side="right", fill="y")
        self.entry.bind("<FocusIn>", lambda e: self.config(highlightbackground=GOLD))
        self.entry.bind("<FocusOut>", lambda e: self.config(highlightbackground=LINE))
        if on_change:
            self.var.trace_add("write", lambda *a: on_change(self.var.get()))

    def toggle(self):
        hidden = self.entry.cget("show") == "*"
        self.entry.config(show="" if hidden else "*")
        self.eye.config(text="HIDE" if hidden else "SHOW", fg=GOLD if hidden else MUTED)

    def get(self):
        return self.var.get()

    def set(self, v):
        self.var.set(v)


class StrengthMeter(tk.Frame):
    SEG = 24

    def __init__(self, master):
        super().__init__(master, bg=master.cget("bg"))
        self.pw = ""
        self.canvas = tk.Canvas(self, height=8, bg=self.cget("bg"), highlightthickness=0)
        self.canvas.pack(fill="x")
        self.canvas.bind("<Configure>", lambda e: self._draw())
        row = tk.Frame(self, bg=self.cget("bg"))
        row.pack(fill="x", pady=(3, 0))
        self.label = tk.Label(row, text="", bg=self.cget("bg"), fg=MUTED, font=(FONT_B, 9))
        self.label.pack(side="left")
        self.bits = tk.Label(row, text="", bg=self.cget("bg"), fg=MUTED, font=(MONO, 9))
        self.bits.pack(side="right")
        self.update_pw("")

    def score(self):
        return core.password_strength(self.pw)[0]

    def _draw(self):
        s = self.score()
        c = self.canvas
        c.delete("all")
        w = max(c.winfo_width(), 50)
        seg = w / self.SEG
        lit = round(s / 100 * self.SEG)
        for i in range(self.SEG):
            t = i / (self.SEG - 1)
            col = lerp_color(RED, AMBER, t * 2) if t < .5 else lerp_color(GOLD, GREEN, (t - .5) * 2)
            c.create_rectangle(i * seg + 1, 0, (i + 1) * seg - 2, 8, fill=col if i < lit else "#1d1d24", width=0)

    def update_pw(self, pw):
        self.pw = pw
        s, label, bits = core.password_strength(pw)
        self._draw()
        col = RED if s < 40 else AMBER if s < 60 else GOLD if s < 80 else GREEN
        self.label.config(text=f"Strength: {label}" if pw else "Strength: —", fg=col if pw else MUTED)
        self.bits.config(text=f"~{bits:.0f} bits" if pw else "")


class Segmented(tk.Frame):
    """Row of toggle buttons; exactly one is active."""

    def __init__(self, master, options, command, value, min_w=150):
        super().__init__(master, bg=master.cget("bg"))
        self.command, self.btns, self.value = command, {}, value
        grid = FlowGrid(self, min_w=min_w, gap=6)
        grid.pack(fill="x")
        for v, label in options:
            b = tk.Button(grid, text=label, command=lambda v=v: self.select(v), relief="flat", bd=0,
                          font=(FONT_B, 10), pady=7, cursor="hand2", highlightthickness=1,
                          highlightbackground=GOLD_DIM)
            grid.add(b)
            self.btns[v] = b
        self.select(value, notify=False)

    def select(self, v, notify=True):
        self.value = v
        for k, b in self.btns.items():
            on = k == v
            b.config(bg=GOLD if on else PANEL2, fg="#0a0a0a" if on else MUTED,
                     activebackground=GOLD_HI if on else PANEL3, activeforeground="#0a0a0a" if on else GOLD)
        if notify:
            self.command(v)


class Logo(tk.Canvas):
    def __init__(self, master, size=64, animate=True):
        super().__init__(master, width=size, height=size, bg=master.cget("bg"), highlightthickness=0)
        self.s, self.t = size, 0.0
        self.draw()
        if animate:
            self.after(60, self.tick)

    def _hex(self, r):
        c = self.s / 2
        pts = []
        for i in range(6):
            a = math.radians(60 * i - 90)
            pts += [c + r * math.cos(a), c + r * math.sin(a)]
        return pts

    def draw(self):
        self.delete("all")
        s = self.s
        r = s * .44
        self.create_polygon(self._hex(r), outline=GOLD_DIM, fill="", width=1)
        self.create_polygon(self._hex(r * .84), outline=GOLD, fill="#0e0c06", width=2)
        # keyhole
        cx, cy = s / 2, s / 2 - s * .06
        kr = s * .1
        self.create_oval(cx - kr, cy - kr, cx + kr, cy + kr, fill=GOLD_HI, outline="")
        self.create_polygon(cx - kr * .55, cy + kr * .4, cx + kr * .55, cy + kr * .4,
                            cx + kr * .9, cy + kr * 2.6, cx - kr * .9, cy + kr * 2.6, fill=GOLD_HI, outline="")
        x, y = s / 2 + r * math.cos(self.t), s / 2 + r * math.sin(self.t)
        for rad, col in ((max(2, s / 18), GOLD_DIM), (max(1.5, s / 26), GOLD), (max(1, s / 44), "#fff6d0")):
            self.create_oval(x - rad, y - rad, x + rad, y + rad, fill=col, outline="")

    def tick(self):
        if not alive(self):
            return
        self.t += .08
        self.draw()
        self.after(60, self.tick)


class KeyFilePicker(tk.Frame):
    """Choose any file (photo, document, random key) - its SHA-512 is the key."""

    def __init__(self, master, app, allow_generate=False, allow_paste=False):
        super().__init__(master, bg=master.cget("bg"))
        self.app, self.hash, self.busy = app, None, False
        self.info = wlabel(self, "No key file selected.", fg=MUTED, font=(FONT, 9))
        row = FlowGrid(self, min_w=170, gap=8)
        row.pack(fill="x", pady=(6, 0))
        row.add(GButton(row, "Choose key file…", self.choose, "ghost"))
        if allow_generate:
            row.add(GButton(row, "Generate new key file…", self.generate, "ghost"))
        self.paste = None
        if allow_paste:
            wlabel(self, "…or paste the file's SHA-512 hash (128 hex characters):", fg=MUTED,
                   font=(FONT, 9), pady=(10, 4))
            self.paste = PasswordEntry(self)
            self.paste.pack(fill="x")

    def choose(self):
        p = filedialog.askopenfilename(parent=self.app, title="Choose key file (any file: photo, document, …)")
        if not p:
            return
        self.hash, self.busy = None, True
        size = os.path.getsize(p)
        self.info.config(text=f"Hashing {Path(p).name} ({core.human_bytes(size)})…", fg=GOLD)
        self.app.run_bg(lambda: core.sha512_file(p),
                        lambda h: self._done(h, f"✓  {Path(p).name} · {core.human_bytes(size)} · SHA-512 ready"),
                        self._err)

    def generate(self):
        p = filedialog.asksaveasfilename(parent=self.app, title="Save new key file", defaultextension=".key",
                                         initialfile="dortress.key",
                                         filetypes=[("Key file", "*.key"), ("All files", "*.*")])
        if not p:
            return
        self.busy = True
        self.app.run_bg(lambda: core.generate_keyfile(p),
                        lambda h: self._done(h, f"✓  New key file created: {Path(p).name}  — "
                                                "back it up now, you cannot open the vault without it."),
                        self._err)

    def _done(self, h, text):
        self.hash, self.busy = h, False
        if alive(self.info):
            self.info.config(text=text, fg=GREEN)

    def _err(self, e):
        self.busy = False
        if alive(self.info):
            self.info.config(text=f"Could not read key file: {e}", fg=RED)

    def get_hash(self):
        if self.paste is not None and self.paste.get().strip():
            return core.normalize_hash(self.paste.get())
        if self.busy:
            raise core.VaultError("Still hashing the key file, please wait a moment.")
        return self.hash


# ----------------------------------------------------------------- app ----
class App(tk.Tk):
    def __init__(self, initial: str | None = None):
        super().__init__()
        self.title(core.APP_NAME)
        self.configure(bg=BG)
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        w, h = min(1240, int(sw * .85)), min(820, int(sh * .85))
        self.geometry(f"{w}x{h}+{(sw - w) // 2}+{max(0, (sh - h) // 2 - 20)}")
        self.minsize(min(560, sw), min(480, sh))
        self.settings = core.Settings()
        self.vault: core.Vault | None = None
        self.q: queue.Queue = queue.Queue()
        self.last_activity = time.time()
        self.fail_count = 0
        self.clip_token = 0
        self.clip_value = None
        self.selected = None
        self.sort = ("title", False)
        self._style()
        self.bind_all("<Key>", self._touch, add="+")
        self.bind_all("<Motion>", self._touch, add="+")
        self.bind_all("<MouseWheel>", self._wheel, add="+")
        self.bind_all("<Button-4>", self._wheel, add="+")
        self.bind_all("<Button-5>", self._wheel, add="+")
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.after(50, self._poll)
        self.after(5000, self._autolock)
        if initial and os.path.isfile(initial):
            self.show_unlock(initial)
        else:
            self.show_welcome()

    # ---------------------------------------------------------- plumbing --
    def _style(self):
        st = ttk.Style(self)
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass
        st.configure("Gold.Vertical.TScrollbar", background=GOLD_DIM, troughcolor=BG, bordercolor=BG,
                     arrowcolor=GOLD, lightcolor=GOLD_DIM, darkcolor=GOLD_DIM, gripcount=0)
        st.map("Gold.Vertical.TScrollbar", background=[("active", GOLD)])
        st.configure("Gold.Treeview", background=PANEL, fieldbackground=PANEL, foreground=TEXT,
                     rowheight=30, borderwidth=0, font=(FONT, 10))
        st.map("Gold.Treeview", background=[("selected", GOLD_DIM)], foreground=[("selected", "#ffffff")])
        st.configure("Gold.Treeview.Heading", background=PANEL2, foreground=GOLD, relief="flat",
                     font=(FONT_B, 9), borderwidth=0)
        st.map("Gold.Treeview.Heading", background=[("active", PANEL3)])
        st.configure("Gold.TCombobox", fieldbackground=PANEL2, background=PANEL2, foreground=TEXT,
                     arrowcolor=GOLD, bordercolor=LINE, lightcolor=PANEL2, darkcolor=PANEL2,
                     selectbackground=PANEL2, selectforeground=TEXT, padding=5)
        st.map("Gold.TCombobox", fieldbackground=[("readonly", PANEL2)], foreground=[("readonly", TEXT)])
        self.option_add("*TCombobox*Listbox.background", PANEL2)
        self.option_add("*TCombobox*Listbox.foreground", TEXT)
        self.option_add("*TCombobox*Listbox.selectBackground", GOLD_DIM)
        self.option_add("*TCombobox*Listbox.font", (FONT, 10))

    def run_bg(self, fn, ok, err=None):
        """Run fn in a thread; deliver result to ok/err on the UI thread."""
        def work():
            try:
                self.q.put((ok, fn()))
            except Exception as e:  # noqa
                self.q.put((err or self._show_error, e))
        threading.Thread(target=work, daemon=True).start()

    def _poll(self):
        try:
            for _ in range(100):
                cb, val = self.q.get_nowait()
                try:
                    cb(val)
                except Exception as e:  # never kill the UI loop
                    print("callback error:", e, file=sys.stderr)
        except queue.Empty:
            pass
        self.after(50, self._poll)

    def _show_error(self, e):
        messagebox.showerror(core.APP_NAME, str(e), parent=self)

    def _touch(self, _e=None):
        self.last_activity = time.time()

    def _wheel(self, e):
        w = e.widget
        if isinstance(w, str):
            try:
                w = self.nametowidget(w)
            except Exception:
                return
        if isinstance(w, (tk.Text, tk.Listbox, ttk.Treeview)):
            return
        n = getattr(e, "num", None)
        steps = -3 if n == 4 else 3 if n == 5 else (-3 if getattr(e, "delta", 0) > 0 else 3)
        while w is not None:
            if isinstance(w, ScrollFrame):
                w.wheel(steps)
                return
            w = getattr(w, "master", None)

    def _autolock(self):
        if self.vault:
            mins = float(self.vault.settings.get("autolock_min", 5) or 0)
            if mins > 0 and time.time() - self.last_activity > mins * 60:
                self.lock(reason="Locked after inactivity.")
        self.after(5000, self._autolock)

    def clear(self):
        for w in self.winfo_children():
            w.destroy()

    def column(self, max_w=560):
        """Centered, scrollable column that shrinks on small windows."""
        self.clear()
        sf = ScrollFrame(self)
        sf.pack(fill="both", expand=True)
        col = tk.Frame(sf.inner, bg=BG)
        col.pack(fill="x", padx=16, pady=26)
        sf.inner.bind("<Configure>", lambda e: col.pack_configure(padx=max(16, (e.width - max_w) // 2)), add="+")
        return col

    def modal(self, title, w=560, h=640):
        top = tk.Toplevel(self, bg=BG)
        top.title(title)
        top.transient(self)
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        w, h = min(w, sw - 40), min(h, sh - 80)
        top.geometry(f"{w}x{h}+{self.winfo_rootx() + max(0, (self.winfo_width() - w) // 2)}"
                     f"+{self.winfo_rooty() + max(0, (self.winfo_height() - h) // 3)}")
        top.minsize(min(360, w), min(300, h))
        top.bind("<Escape>", lambda e: top.destroy())
        try:
            top.wait_visibility()
            top.grab_set()
        except tk.TclError:
            pass
        sf = ScrollFrame(top)
        sf.pack(fill="both", expand=True)
        body = tk.Frame(sf.inner, bg=BG)
        body.pack(fill="both", expand=True, padx=20, pady=18)
        return top, body

    def on_close(self):
        self._clear_clipboard_if_ours()
        if self.vault:
            self.vault.lock()
        self.destroy()

    # -------------------------------------------------------- clipboard --
    def copy(self, value, what):
        if not value:
            self.status(f"{what} is empty.", AMBER)
            return
        secs = int(self.vault.settings.get("clip_seconds", 20)) if self.vault else 20
        self.clipboard_clear()
        self.clipboard_append(value)
        self.clip_token += 1
        self.clip_value = value
        tok = self.clip_token
        self.status(f"{what} copied — clipboard clears in {secs} s", GREEN)
        self.after(secs * 1000, lambda: self.clip_token == tok and self._clear_clipboard_if_ours())

    def _clear_clipboard_if_ours(self):
        if self.clip_value is None:
            return
        try:
            if self.clipboard_get() == self.clip_value:
                self.clipboard_clear()
                self.clipboard_append("")
                if alive(getattr(self, "status_lbl", None)):
                    self.status("Clipboard cleared.", MUTED)
        except tk.TclError:
            pass
        self.clip_value = None

    # ------------------------------------------------------------ welcome --
    def show_welcome(self):
        self.vault = None
        col = self.column(600)
        Logo(col, 92).pack()
        tk.Label(col, text="DORTRESS", bg=BG, fg=GOLD_HI, font=(FONT_B, 26)).pack(pady=(8, 0))
        tk.Label(col, text="PASSWORD MANAGER", bg=BG, fg=GOLD, font=(FONT_B, 11)).pack()
        tk.Label(col, text="Portable · AES-256-GCM at rest · Argon2id", bg=BG, fg=MUTED,
                 font=(FONT, 10)).pack(pady=(4, 20))
        grid = FlowGrid(col, min_w=230, gap=12)
        grid.pack(fill="x")
        for glyph, title, desc, label, cmd, kind in (
                ("✦", "Create new vault", "Choose where to save it and give it any name.",
                 "Create vault", self.show_create, "primary"),
                ("⬡", "Open vault", "Open a .dpm vault from any drive, USB stick or folder.",
                 "Open vault…", self.open_dialog, "ghost")):
            outer, inner = card(grid)
            grid.add(outer)
            tk.Label(inner, text=glyph, bg=PANEL, fg=GOLD, font=(FONT_B, 22), anchor="w").pack(fill="x")
            tk.Label(inner, text=title, bg=PANEL, fg=TEXT, font=(FONT_B, 13), anchor="w").pack(fill="x")
            wlabel(inner, desc, fg=MUTED, font=(FONT, 9))
            GButton(inner, label, cmd, kind).pack(fill="x", pady=(12, 0))
        rec = self.settings.recent
        if rec:
            outer, inner = card(col, "Recent vaults")
            outer.pack(fill="x", pady=(18, 0))
            for p in rec:
                exists = os.path.isfile(p)
                row = tk.Frame(inner, bg=PANEL)
                row.pack(fill="x", pady=3)
                tk.Button(row, text="✕", command=lambda p=p: (self.settings.remove_recent(p), self.show_welcome()),
                          bg=PANEL, fg=MUTED, activebackground=PANEL3, activeforeground=RED, relief="flat",
                          bd=0, font=(FONT_B, 9), cursor="hand2", padx=8, highlightthickness=0).pack(side="right")
                b = tk.Button(row, text=f"{Path(p).name}\n{p}" + ("" if exists else "   (not found)"),
                              command=lambda p=p: self.show_unlock(p), justify="left", anchor="w",
                              bg=PANEL2, fg=TEXT if exists else MUTED, activebackground=PANEL3,
                              activeforeground=GOLD_HI, relief="flat", bd=0, font=(FONT, 9), padx=12,
                              pady=6, cursor="hand2", highlightthickness=0,
                              state="normal" if exists else "disabled")
                b.pack(side="left", fill="x", expand=True)
        tk.Label(col, text=f"v{core.VERSION}  ·  {core.DEVELOPER}", bg=BG, fg=GOLD_DIM,
                 font=(FONT, 9)).pack(pady=(20, 0))

    def open_dialog(self):
        p = filedialog.askopenfilename(parent=self, title="Open Dortress vault", filetypes=VAULT_TYPES)
        if p:
            self.show_unlock(p)

    # ------------------------------------------------------------- create --
    def master_key_form(self, parent, mode=core.MODE_PASSWORD, allow_paste=False):
        """Shared form for 'create vault' and 'change master key'. Returns getter."""
        holder = tk.Frame(parent, bg=parent.cget("bg"))
        desc = wlabel(parent, "", fg=MUTED, font=(FONT, 9), pady=(8, 0))
        Segmented(parent, [(core.MODE_PASSWORD, "Password"), (core.MODE_KEYFILE, "Key file"),
                           (core.MODE_BOTH, "Password + key file")],
                  lambda v: render(v), mode, min_w=140).pack(fill="x", before=desc)
        holder.pack(fill="x")
        pw_box = tk.Frame(holder, bg=parent.cget("bg"))
        kf_box = tk.Frame(holder, bg=parent.cget("bg"))
        state = {"mode": mode}

        flabel(pw_box, "Master password")
        meter = StrengthMeter(pw_box)
        pw = PasswordEntry(pw_box, meter.update_pw)
        pw.pack(fill="x")
        meter.pack(fill="x", pady=(6, 0))
        flabel(pw_box, "Confirm master password")
        cf = PasswordEntry(pw_box)
        cf.pack(fill="x")

        def gen():
            g = core.generate_dortress()
            pw.set(g)
            cf.set(g)
            self.show_secret("Generated master password", g,
                             "Write it down and keep it offline. It is never stored and cannot be recovered.")

        GButton(pw_box, "Generate strong password", gen, "ghost").pack(anchor="w", pady=(10, 0))

        flabel(kf_box, "Key file")
        picker = KeyFilePicker(kf_box, self, allow_generate=True, allow_paste=allow_paste)
        picker.pack(fill="x")
        wlabel(kf_box, "Any file works (a photo, a PDF, a random .key file). Its SHA-512 hash becomes "
                       "the key. If the file changes by even one byte, or is lost, the vault cannot be "
                       "opened. Keep copies and never edit the file.",
               fg=AMBER, font=(FONT, 9), pady=(10, 0))

        texts = {core.MODE_PASSWORD: "A master password you remember. Recommended: 10 numbers, "
                                     "3 uppercase, 3 lowercase, 4 special characters.",
                 core.MODE_KEYFILE: "No password to type: the SHA-512 hash of a file you choose is the "
                                    "master key. Whoever has the file can open the vault.",
                 core.MODE_BOTH: "Strongest: an attacker needs BOTH your password and your key file."}

        def render(m):
            state["mode"] = m
            pw_box.pack_forget()
            kf_box.pack_forget()
            if core.needs_password(m):
                pw_box.pack(fill="x")
            if core.needs_keyfile(m):
                kf_box.pack(fill="x", pady=(8, 0))
            desc.config(text=texts[m])

        render(mode)

        def collect():
            m = state["mode"]
            password = keyhash = None
            if core.needs_password(m):
                password = pw.get()
                if not password:
                    raise core.VaultError("Enter a master password.")
                if password != cf.get():
                    raise core.VaultError("Passwords do not match.")
                if meter.score() < 60 and not messagebox.askyesno(
                        "Weak password", "This master password is weak and could be guessed.\n\n"
                                         "Use it anyway?", icon="warning", parent=self):
                    return None
            if core.needs_keyfile(m):
                keyhash = picker.get_hash()
                if not keyhash:
                    raise core.VaultError("Choose or generate a key file.")
            return m, password, keyhash

        return collect

    def show_create(self):
        col = self.column(600)
        tk.Label(col, text="Create a new vault", bg=BG, fg=GOLD_HI, font=(FONT_B, 20), anchor="w").pack(fill="x")
        tk.Frame(col, bg=GOLD_DIM, height=1).pack(fill="x", pady=(10, 16))

        outer, inner = card(col, "1 · Where to save it")
        outer.pack(fill="x")
        state = {"path": None}
        path_lbl = wlabel(inner, "No location chosen yet.", fg=MUTED, font=(FONT, 9))
        flabel(inner, "Vault display name")
        name_e = gentry(inner)

        def choose():
            p = filedialog.asksaveasfilename(parent=self, title="Save new vault as", defaultextension=core.EXT,
                                             initialfile="MyPasswords" + core.EXT, filetypes=VAULT_TYPES)
            if p:
                state["path"] = p
                path_lbl.config(text=p, fg=GOLD_HI)
                if not name_e.get().strip():
                    name_e.insert(0, Path(p).stem)

        GButton(inner, "Choose location & file name…", choose, "ghost").pack(anchor="w", pady=(12, 0))

        outer, inner = card(col, "2 · Master key")
        outer.pack(fill="x", pady=(14, 0))
        collect = self.master_key_form(inner)

        status = wlabel(col, "", fg=RED, font=(FONT, 9), pady=(12, 0))
        row = tk.Frame(col, bg=BG)
        row.pack(fill="x", pady=(10, 0))
        GButton(row, "Back", self.show_welcome, "ghost").pack(side="left")

        def create():
            if not state["path"]:
                status.config(text="Choose where to save the vault first.", fg=RED)
                return
            try:
                got = collect()
            except core.VaultError as e:
                status.config(text=str(e), fg=RED)
                return
            if not got:
                return
            m, password, keyhash = got
            status.config(text="Creating vault (Argon2id key derivation)…", fg=GOLD)
            btn.set_enabled(False)
            path, name = state["path"], name_e.get().strip() or Path(state["path"]).stem

            def ok(v):
                self.vault = v
                self.settings.add_recent(v.path)
                self.show_main()
                self.status(f"Vault created: {v.path}", GREEN)

            def err(e):
                if alive(btn):
                    btn.set_enabled(True)
                    status.config(text=f"Could not create vault: {e}", fg=RED)

            self.run_bg(lambda: core.Vault.create(path, m, password, keyhash, name), ok, err)

        btn = GButton(row, "CREATE VAULT", create, "primary", size=11, padx=24, pady=8)
        btn.pack(side="right")

    # ------------------------------------------------------------- unlock --
    def show_unlock(self, path, note=None):
        try:
            hdr = core.read_header(path)
        except Exception as e:
            messagebox.showerror(core.APP_NAME, f"Cannot open this file:\n{e}", parent=self)
            self.show_welcome()
            return
        self.vault = None
        mode = hdr["mode"]
        col = self.column(520)
        Logo(col, 80).pack()
        tk.Label(col, text=Path(path).name, bg=BG, fg=GOLD_HI, font=(FONT_B, 18)).pack(pady=(8, 0))
        wlabel(col, path, fg=MUTED, font=(FONT, 9), pady=(2, 0)).config(justify="center", anchor="center")
        if note:
            tk.Label(col, text=note, bg=BG, fg=AMBER, font=(FONT, 9)).pack(pady=(6, 0))
        outer, box = card(col, f"Unlock  ·  {core.MODE_NAMES[mode]}")
        outer.pack(fill="x", pady=(16, 0))
        pw = picker = None
        if core.needs_password(mode):
            flabel(box, "Master password")
            pw = PasswordEntry(box)
            pw.pack(fill="x")
            pw.entry.focus_set()
        if core.needs_keyfile(mode):
            flabel(box, "Key file")
            picker = KeyFilePicker(box, self, allow_paste=True)
            picker.pack(fill="x")
        status = wlabel(box, "", fg=RED, font=(FONT, 9), pady=(10, 0))

        def unlock():
            try:
                password = pw.get() if pw else None
                keyhash = picker.get_hash() if picker else None
                core.build_secret(mode, password, keyhash)  # validates presence
            except core.VaultError as e:
                status.config(text=str(e), fg=AMBER)
                return
            delay = min(30, 2 ** self.fail_count - 1) if self.fail_count else 0
            status.config(text="Unlocking…" + (f" (waiting {delay}s after failed attempts)" if delay else ""),
                          fg=GOLD)
            btn.set_enabled(False)

            def work():
                time.sleep(delay)
                return core.Vault.open(path, password, keyhash)

            def ok(v):
                self.vault, self.fail_count = v, 0
                self.settings.add_recent(path)
                self.last_activity = time.time()
                self.show_main()

            def err(e):
                self.fail_count += 1
                if alive(btn):
                    btn.set_enabled(True)
                    status.config(text="Wrong master key." if isinstance(e, core.WrongKey) else str(e), fg=RED)

            self.run_bg(work, ok, err)

        btn = GButton(box, "UNLOCK", unlock, "primary", size=11, pady=9)
        btn.pack(fill="x", pady=(14, 0))
        if pw:
            pw.entry.bind("<Return>", lambda e: unlock())
        row = tk.Frame(col, bg=BG)
        row.pack(fill="x", pady=(14, 0))
        GButton(row, "Open a different vault…", self.open_dialog, "ghost").pack(side="left")
        GButton(row, "Home", self.show_welcome, "ghost").pack(side="right")

    def lock(self, reason=None):
        if not self.vault:
            return
        path = str(self.vault.path)
        for w in self.winfo_children():
            if isinstance(w, tk.Toplevel):
                w.destroy()
        self._clear_clipboard_if_ours()
        self.vault.lock()
        self.vault = None
        self.show_unlock(path, reason)

    # --------------------------------------------------------------- main --
    def show_main(self):
        self.clear()
        self.selected = None
        top = tk.Frame(self, bg=PANEL)
        top.pack(side="top", fill="x")
        tk.Frame(self, bg=GOLD_DIM, height=1).pack(side="top", fill="x")
        brand = tk.Frame(top, bg=PANEL)
        brand.pack(side="left", padx=(12, 8), pady=8)
        Logo(brand, 36).pack(side="left")
        names = tk.Frame(brand, bg=PANEL)
        names.pack(side="left", padx=(8, 0))
        self.vault_lbl = tk.Label(names, text=self.vault.name, bg=PANEL, fg=GOLD_HI, font=(FONT_B, 13), anchor="w")
        self.vault_lbl.pack(fill="x")
        tk.Label(names, text="DORTRESS PASSWORD MANAGER", bg=PANEL, fg=GOLD_DIM, font=(FONT_B, 7),
                 anchor="w").pack(fill="x")
        GButton(top, "🔒 Lock", self.lock, "ghost", padx=12, pady=4).pack(side="right", padx=12)

        bar = tk.Frame(self, bg=BG)
        bar.pack(side="top", fill="x", padx=16, pady=(12, 0))
        tools = FlowGrid(bar, min_w=128, gap=8)
        tools.pack(fill="x")
        for label, cmd, kind in (("+  New entry", lambda: self.entry_dialog(), "primary"),
                                 ("Generator", lambda: self.generator_dialog(), "ghost"),
                                 ("Save as…", self.save_as, "ghost"),
                                 ("Master key…", self.master_key_dialog, "ghost"),
                                 ("Settings", self.settings_dialog, "ghost")):
            tools.add(GButton(tools, label, cmd, kind))

        filt = tk.Frame(self, bg=BG)
        filt.pack(side="top", fill="x", padx=16, pady=10)
        sbox = tk.Frame(filt, bg=PANEL2, highlightthickness=1, highlightbackground=LINE, highlightcolor=GOLD)
        sbox.pack(side="left", fill="x", expand=True)
        tk.Label(sbox, text="⌕", bg=PANEL2, fg=GOLD, font=(FONT_B, 13)).pack(side="left", padx=(8, 0))
        self.search_var = tk.StringVar()
        self.search = tk.Entry(sbox, textvariable=self.search_var, bd=0, relief="flat", bg=PANEL2, fg=TEXT,
                               insertbackground=GOLD, font=(FONT, 11))
        self.search.pack(side="left", fill="x", expand=True, padx=8, pady=7)
        self.search_var.trace_add("write", lambda *a: self.refresh_list())
        self.folder_var = tk.StringVar(value="All folders")
        self.folder_cb = ttk.Combobox(filt, textvariable=self.folder_var, state="readonly", width=16,
                                      style="Gold.TCombobox", font=(FONT, 10))
        self.folder_cb.pack(side="left", padx=(10, 0))
        self.folder_cb.bind("<<ComboboxSelected>>", lambda e: self.refresh_list())

        sb = tk.Frame(self, bg=PANEL)
        sb.pack(side="bottom", fill="x")
        tk.Frame(self, bg=GOLD_DIM, height=1).pack(side="bottom", fill="x")
        self.status_lbl = tk.Label(sb, text="", bg=PANEL, fg=MUTED, font=(FONT, 9), anchor="w")
        self.status_lbl.pack(side="left", fill="x", expand=True, padx=12, pady=5)
        self.count_lbl = tk.Label(sb, text="", bg=PANEL, fg=GOLD_DIM, font=(FONT, 9))
        self.count_lbl.pack(side="right", padx=12)

        self.body = tk.Frame(self, bg=BG)
        self.body.pack(side="top", fill="both", expand=True, padx=16, pady=(0, 12))
        self.list_frame = tk.Frame(self.body, bg=PANEL, highlightthickness=1, highlightbackground=LINE)
        cols = ("title", "username", "url", "folder", "modified")
        self.tree = ttk.Treeview(self.list_frame, columns=cols, show="headings", style="Gold.Treeview",
                                 selectmode="browse")
        for c, label, w in (("title", "Title", 200), ("username", "Username", 180), ("url", "Website", 180),
                            ("folder", "Folder", 110), ("modified", "Modified", 140)):
            self.tree.heading(c, text=label, command=lambda c=c: self.sort_by(c))
            self.tree.column(c, width=w, minwidth=60, stretch=True)
        vsb = ttk.Scrollbar(self.list_frame, orient="vertical", command=self.tree.yview,
                            style="Gold.Vertical.TScrollbar")
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.on_select())
        self.tree.bind("<Double-1>", lambda e: self.selected and self.entry_dialog(self.selected))
        self.tree.bind("<Return>", lambda e: self.selected and self.entry_dialog(self.selected))
        self.tree.bind("<Delete>", lambda e: self.delete_selected())
        self.tree.bind("<Control-c>", lambda e: self.copy_field("password"))
        self.tree.bind("<Control-b>", lambda e: self.copy_field("username"))
        self.tree.bind("<Control-u>", lambda e: self.open_url())
        self.bind("<Control-f>", lambda e: self.search.focus_set())
        self.bind("<Control-n>", lambda e: self.entry_dialog())
        self.bind("<Control-l>", lambda e: self.lock())

        self.detail = ScrollFrame(self.body, bg=PANEL)
        self.detail.configure(highlightthickness=1, highlightbackground=LINE)
        self.layout_mode = None
        self.body.bind("<Configure>", self._layout_body)
        self._layout_body(None, force_w=self.winfo_width())
        self.refresh_list()
        self.show_detail()
        self.status(f"Unlocked · {self.vault.path}", MUTED)

    def _layout_body(self, e, force_w=None):
        w = force_w if force_w is not None else e.width
        mode = "wide" if w >= 900 else "narrow"
        if mode == self.layout_mode:
            return
        self.layout_mode = mode
        self.list_frame.grid_forget()
        self.detail.grid_forget()
        for i in range(2):
            self.body.columnconfigure(i, weight=0, minsize=0)
            self.body.rowconfigure(i, weight=0)
        if mode == "wide":
            self.body.columnconfigure(0, weight=1)
            self.body.columnconfigure(1, weight=0, minsize=380)
            self.body.rowconfigure(0, weight=1)
            self.list_frame.grid(row=0, column=0, sticky="nsew")
            self.detail.grid(row=0, column=1, sticky="nsew", padx=(12, 0))
            self.tree.configure(displaycolumns=("title", "username", "url", "folder", "modified"))
        else:
            self.body.columnconfigure(0, weight=1)
            self.body.rowconfigure(0, weight=3)
            self.body.rowconfigure(1, weight=2)
            self.list_frame.grid(row=0, column=0, sticky="nsew")
            self.detail.grid(row=1, column=0, sticky="nsew", pady=(12, 0))
            self.tree.configure(displaycolumns=("title", "username", "folder"))

    def status(self, text, color=MUTED):
        if alive(getattr(self, "status_lbl", None)):
            self.status_lbl.config(text=text, fg=color)

    def persist(self, msg="Saved"):
        try:
            self.vault.save()
            self.status(f"{msg} ✓  {time.strftime('%H:%M:%S')}  ·  {self.vault.path}", GREEN)
            return True
        except Exception as e:
            self.status(f"SAVE FAILED: {e}", RED)
            messagebox.showerror(core.APP_NAME, f"Could not save the vault:\n{e}\n\n"
                                                "Your changes are still in memory. Try 'Save as…' "
                                                "to another location.", parent=self)
            return False

    # ------------------------------------------------------------- list --
    def sort_by(self, col):
        cur, rev = self.sort
        self.sort = (col, not rev if cur == col else False)
        self.refresh_list()

    def refresh_list(self):
        if not self.vault or not alive(getattr(self, "tree", None)):
            return
        folders = self.vault.folders()
        self.folder_cb.configure(values=["All folders"] + folders)
        f = self.folder_var.get()
        if f != "All folders" and f not in folders:
            self.folder_var.set("All folders")
            f = "All folders"
        items = self.vault.search(self.search_var.get(), None if f == "All folders" else f)
        col, rev = self.sort
        key = (lambda e: float(e.get("modified", 0))) if col == "modified" else \
              (lambda e: str(e.get(col, "")).lower())
        items.sort(key=key, reverse=rev)
        self.tree.delete(*self.tree.get_children())
        for e in items:
            self.tree.insert("", "end", iid=e["id"], values=(
                e.get("title", ""), e.get("username", ""), e.get("url", ""), e.get("folder", ""),
                fmt_time(e.get("modified"))))
        if self.selected and self.tree.exists(self.selected):
            self.tree.selection_set(self.selected)
            self.tree.see(self.selected)
        total = len(self.vault.entries)
        self.count_lbl.config(text=f"{len(items)} of {total} entr{'y' if total == 1 else 'ies'}")

    def on_select(self):
        sel = self.tree.selection()
        self.selected = sel[0] if sel else None
        self.show_detail()

    def show_detail(self):
        inner = self.detail.inner
        for w in inner.winfo_children():
            w.destroy()
        box = tk.Frame(inner, bg=PANEL)
        box.pack(fill="both", expand=True, padx=18, pady=16)
        e = self.vault.get(self.selected) if self.selected else None
        if not e:
            tk.Label(box, text="🔑", bg=PANEL, fg=GOLD_DIM, font=(FONT, 30)).pack(pady=(30, 4))
            msg = "Select an entry to see its details." if self.vault.entries else \
                  "Your vault is empty. Add your first password."
            wlabel(box, msg, fg=MUTED).config(justify="center", anchor="center")
            GButton(box, "+  New entry", lambda: self.entry_dialog(), "primary").pack(pady=14)
            return
        wlabel(box, e.get("title") or "(untitled)", fg=GOLD_HI, font=(FONT_B, 17))
        if e.get("folder"):
            tk.Label(box, text=f"  {e['folder']}  ", bg=PANEL3, fg=GOLD, font=(FONT_B, 8)).pack(anchor="w", pady=(4, 0))
        tk.Frame(box, bg=LINE, height=1).pack(fill="x", pady=12)

        def row(label, value, buttons, mono=False, masked=False):
            tk.Label(box, text=label.upper(), bg=PANEL, fg=GOLD_DIM, font=(FONT_B, 8), anchor="w").pack(fill="x")
            r = tk.Frame(box, bg=PANEL)
            r.pack(fill="x", pady=(2, 12))
            bf = tk.Frame(r, bg=PANEL)
            bf.pack(side="right")
            shown = "•" * 12 if (masked and value) else (value or "—")
            lb = tk.Label(r, text=shown, bg=PANEL, fg=TEXT if value else MUTED,
                          font=(MONO, 11) if mono else (FONT, 11), anchor="w", justify="left")
            lb.pack(side="left", fill="x", expand=True)
            lb.bind("<Configure>", lambda ev: lb.config(wraplength=max(60, ev.width - 4)))
            for text, cmd in buttons:
                b = GButton(bf, text, None, "ghost", size=8, padx=8, pady=2)
                b.config(command=(lambda c=cmd, b=b, lb=lb: c(b, lb)))
                b.pack(side="left", padx=(4, 0))

        row("Username", e.get("username"), [("Copy", lambda b, l: self.copy(e.get("username"), "Username"))])

        def toggle(b, lb):
            hidden = lb.cget("text").startswith("•")
            lb.config(text=e.get("password") if hidden else "•" * 12)
            b.config(text="Hide" if hidden else "Show")

        row("Password", e.get("password"),
            [("Show", toggle), ("Copy", lambda b, l: self.copy(e.get("password"), "Password"))],
            mono=True, masked=True)
        if e.get("password"):
            s, label, bits = core.password_strength(e["password"])
            col = RED if s < 40 else AMBER if s < 60 else GOLD if s < 80 else GREEN
            tk.Label(box, text=f"{label} · ~{bits:.0f} bits", bg=PANEL, fg=col, font=(FONT, 8),
                     anchor="w").pack(fill="x", pady=(0, 10))
        row("Website", e.get("url"), [("Open", lambda b, l: self.open_url()),
                                       ("Copy", lambda b, l: self.copy(e.get("url"), "Website"))])
        if e.get("notes"):
            tk.Label(box, text="NOTES", bg=PANEL, fg=GOLD_DIM, font=(FONT_B, 8), anchor="w").pack(fill="x")
            wlabel(box, e["notes"], font=(FONT, 10), pady=(2, 12))
        hist = e.get("history") or []
        meta = f"Created {fmt_time(e.get('created'))}\nModified {fmt_time(e.get('modified'))}"
        if hist:
            meta += f"\n{len(hist)} previous password{'s' if len(hist) > 1 else ''} kept"
        wlabel(box, meta, fg=MUTED, font=(FONT, 8))
        btns = FlowGrid(box, min_w=110, gap=8)
        btns.pack(fill="x", pady=(14, 0))
        btns.add(GButton(btns, "Edit", lambda: self.entry_dialog(e["id"]), "primary"))
        if hist:
            btns.add(GButton(btns, "History", lambda: self.history_dialog(e["id"]), "ghost"))
        btns.add(GButton(btns, "Delete", self.delete_selected, "danger"))

    def copy_field(self, field):
        e = self.vault.get(self.selected) if (self.vault and self.selected) else None
        if e:
            self.copy(e.get(field), field.capitalize())
        return "break"

    def open_url(self):
        e = self.vault.get(self.selected) if (self.vault and self.selected) else None
        if not e or not e.get("url"):
            return
        u = e["url"].strip()
        if "://" not in u:
            u = "https://" + u
        if u.lower().startswith(("http://", "https://")):
            webbrowser.open(u)
        else:
            self.status("Only http/https links are opened.", AMBER)

    def delete_selected(self):
        e = self.vault.get(self.selected) if (self.vault and self.selected) else None
        if not e:
            return
        if messagebox.askyesno("Delete entry", f"Delete '{e.get('title') or '(untitled)'}' permanently?",
                               icon="warning", parent=self):
            self.vault.delete_entry(e["id"])
            self.selected = None
            if self.persist("Deleted"):
                self.refresh_list()
                self.show_detail()

    # ---------------------------------------------------------- dialogs --
    def entry_dialog(self, eid=None):
        if not self.vault:
            return
        e = self.vault.get(eid) if eid else None
        top, body = self.modal("Edit entry" if e else "New entry", 580, 720)
        tk.Label(body, text="Edit entry" if e else "New entry", bg=BG, fg=GOLD_HI, font=(FONT_B, 17),
                 anchor="w").pack(fill="x")
        tk.Frame(body, bg=GOLD_DIM, height=1).pack(fill="x", pady=(8, 4))
        g = (lambda k: (e or {}).get(k, ""))
        flabel(body, "Title *")
        title = gentry(body, g("title"))
        flabel(body, "Username / email")
        user = gentry(body, g("username"))
        flabel(body, "Password")
        meter = StrengthMeter(body)
        pw = PasswordEntry(body, meter.update_pw, g("password"))
        pw.pack(fill="x")
        meter.pack(fill="x", pady=(6, 0))
        meter.update_pw(pw.get())
        pr = tk.Frame(body, bg=BG)
        pr.pack(fill="x", pady=(8, 0))
        GButton(pr, "Generate…", lambda: self.generator_dialog(target=pw), "ghost", size=9).pack(side="left")
        GButton(pr, "Quick: Dortress 20", lambda: pw.set(core.generate_dortress()), "ghost", size=9).pack(
            side="left", padx=8)
        flabel(body, "Website")
        url = gentry(body, g("url"))
        flabel(body, "Folder (type a new one or pick)")
        folder = ttk.Combobox(body, values=self.vault.folders(), style="Gold.TCombobox", font=(FONT, 11))
        folder.set(g("folder"))
        folder.pack(fill="x")
        flabel(body, "Notes")
        nf = tk.Frame(body, bg=PANEL2, highlightthickness=1, highlightbackground=LINE)
        nf.pack(fill="x")
        notes = tk.Text(nf, height=5, bd=0, bg=PANEL2, fg=TEXT, insertbackground=GOLD, font=(FONT, 10),
                        wrap="word", highlightthickness=0)
        notes.pack(fill="x", padx=8, pady=6)
        notes.insert("1.0", g("notes"))
        err = wlabel(body, "", fg=RED, font=(FONT, 9), pady=(8, 0))

        def save():
            fields = {"title": title.get().strip(), "username": user.get().strip(), "password": pw.get(),
                      "url": url.get().strip(), "folder": folder.get().strip(),
                      "notes": notes.get("1.0", "end-1c")}
            if not fields["title"]:
                err.config(text="Title is required.")
                title.focus_set()
                return
            if e:
                self.vault.update_entry(e["id"], fields)
                new_id = e["id"]
            else:
                new_id = self.vault.add_entry(fields)
            if self.persist("Saved"):
                top.destroy()
                self.selected = new_id
                self.refresh_list()
                self.show_detail()

        row = tk.Frame(body, bg=BG)
        row.pack(fill="x", pady=(16, 0))
        GButton(row, "Cancel", top.destroy, "ghost").pack(side="left")
        GButton(row, "SAVE", save, "primary", padx=28).pack(side="right")
        top.bind("<Control-s>", lambda ev: save())
        title.focus_set()

    def generator_dialog(self, target: PasswordEntry | None = None):
        top, body = self.modal("Password generator", 560, 560)
        tk.Label(body, text="Password generator", bg=BG, fg=GOLD_HI, font=(FONT_B, 17), anchor="w").pack(fill="x")
        tk.Frame(body, bg=GOLD_DIM, height=1).pack(fill="x", pady=(8, 12))
        out = tk.Label(body, text="", bg=PANEL2, fg=GOLD_HI, font=(MONO, 14), padx=12, pady=12,
                       anchor="w", justify="left")
        out.pack(fill="x")
        out.bind("<Configure>", lambda e: out.config(wraplength=max(60, e.width - 24)))
        info = tk.Label(body, text="", bg=BG, fg=GREEN, font=(FONT, 9), anchor="w")
        info.pack(fill="x", pady=(4, 10))
        length = tk.IntVar(value=24)
        opts = {k: tk.BooleanVar(value=v) for k, v in
                (("upper", True), ("lower", True), ("digits", True), ("symbols", True), ("avoid", False))}
        state = {"pw": ""}

        def regen(*_):
            state["pw"] = core.generate_password(length.get(), opts["upper"].get(), opts["lower"].get(),
                                                 opts["digits"].get(), opts["symbols"].get(), opts["avoid"].get())
            show(core.generated_entropy(length.get(), opts["upper"].get(), opts["lower"].get(),
                                        opts["digits"].get(), opts["symbols"].get(), opts["avoid"].get()))

        def show(bits):
            out.config(text=state["pw"])
            info.config(text=f"{len(state['pw'])} characters · ~{bits:.0f} bits of randomness",
                        fg=GREEN if bits >= 80 else GOLD if bits >= 60 else AMBER)

        def dortress():
            state["pw"] = core.generate_dortress()
            show(core.generated_entropy(20, True, True, True, True) - 15)

        tk.Label(body, text="Length", bg=BG, fg=TEXT, font=(FONT_B, 9), anchor="w").pack(fill="x")
        tk.Scale(body, from_=8, to=128, orient="horizontal", variable=length, command=regen, bg=BG, fg=GOLD,
                 troughcolor=PANEL2, highlightthickness=0, activebackground=GOLD_HI, sliderrelief="flat",
                 bd=0, font=(FONT, 9)).pack(fill="x")
        checks = FlowGrid(body, min_w=150, gap=6)
        checks.pack(fill="x", pady=(6, 0))
        for k, label in (("upper", "A–Z uppercase"), ("lower", "a–z lowercase"), ("digits", "0–9 digits"),
                         ("symbols", "!@# symbols"), ("avoid", "Avoid look-alikes (l, 1, O, 0)")):
            checks.add(tk.Checkbutton(checks, text=label, variable=opts[k], command=regen, bg=BG, fg=TEXT,
                                      selectcolor=PANEL2, activebackground=BG, activeforeground=GOLD_HI,
                                      font=(FONT, 10), anchor="w", highlightthickness=0, bd=0))
        btns = FlowGrid(body, min_w=120, gap=8)
        btns.pack(fill="x", pady=(16, 0))
        btns.add(GButton(btns, "↻  Regenerate", regen, "ghost"))
        btns.add(GButton(btns, "Dortress 10·3·3·4", dortress, "ghost"))
        btns.add(GButton(btns, "Copy", lambda: self.copy(state["pw"], "Password"), "ghost"))
        if target is not None:
            btns.add(GButton(btns, "Use this password", lambda: (target.set(state["pw"]), top.destroy()), "primary"))
        regen()

    def history_dialog(self, eid):
        e = self.vault.get(eid)
        if not e:
            return
        top, body = self.modal("Password history", 520, 480)
        tk.Label(body, text=f"Previous passwords · {e.get('title')}", bg=BG, fg=GOLD_HI, font=(FONT_B, 14),
                 anchor="w").pack(fill="x")
        tk.Frame(body, bg=GOLD_DIM, height=1).pack(fill="x", pady=(8, 12))
        for h in e.get("history", []):
            outer, inner = card(body, accent=GOLD_DIM)
            outer.pack(fill="x", pady=4)
            tk.Label(inner, text=f"Replaced {fmt_time(h.get('changed'))}", bg=PANEL, fg=MUTED, font=(FONT, 8),
                     anchor="w").pack(fill="x")
            r = tk.Frame(inner, bg=PANEL)
            r.pack(fill="x")
            lb = tk.Label(r, text="•" * 12, bg=PANEL, fg=TEXT, font=(MONO, 11), anchor="w")
            lb.pack(side="left", fill="x", expand=True)
            GButton(r, "Copy", lambda p=h.get("password"): self.copy(p, "Old password"), "ghost", size=8,
                    padx=8, pady=2).pack(side="right")
            sb = GButton(r, "Show", None, "ghost", size=8, padx=8, pady=2)
            sb.config(command=lambda lb=lb, sb=sb, p=h.get("password"): (
                lb.config(text=p if lb.cget("text").startswith("•") else "•" * 12),
                sb.config(text="Hide" if lb.cget("text") == p else "Show")))
            sb.pack(side="right", padx=4)

    def master_key_dialog(self):
        top, body = self.modal("Change master key", 600, 720)
        tk.Label(body, text="Change master key", bg=BG, fg=GOLD_HI, font=(FONT_B, 17), anchor="w").pack(fill="x")
        wlabel(body, f"Current: {core.MODE_NAMES[self.vault.mode]}. The vault is re-encrypted with a new "
                     "random salt. Old backups (.bak) still open with the old key.", fg=MUTED, font=(FONT, 9),
               pady=(4, 0))
        tk.Frame(body, bg=GOLD_DIM, height=1).pack(fill="x", pady=(8, 8))
        collect = self.master_key_form(body, self.vault.mode)
        err = wlabel(body, "", fg=RED, font=(FONT, 9), pady=(10, 0))

        def apply():
            try:
                got = collect()
            except core.VaultError as e:
                err.config(text=str(e))
                return
            if not got:
                return
            m, password, keyhash = got
            btn.set_enabled(False)
            err.config(text="Re-encrypting vault…", fg=GOLD)

            def ok(_):
                if alive(top):
                    top.destroy()
                self.status(f"Master key changed to: {core.MODE_NAMES[m]} ✓", GREEN)
                messagebox.showinfo(core.APP_NAME, "Master key changed.\n\nIf you use a key file, back it "
                                                   "up now.", parent=self)

            def fail(e):
                if alive(btn):
                    btn.set_enabled(True)
                    err.config(text=f"Could not change master key: {e}", fg=RED)

            self.run_bg(lambda: self.vault.change_master(m, password, keyhash), ok, fail)

        row = tk.Frame(body, bg=BG)
        row.pack(fill="x", pady=(14, 0))
        GButton(row, "Cancel", top.destroy, "ghost").pack(side="left")
        btn = GButton(row, "CHANGE MASTER KEY", apply, "primary")
        btn.pack(side="right")

    def settings_dialog(self):
        top, body = self.modal("Settings", 520, 520)
        tk.Label(body, text="Settings", bg=BG, fg=GOLD_HI, font=(FONT_B, 17), anchor="w").pack(fill="x")
        tk.Frame(body, bg=GOLD_DIM, height=1).pack(fill="x", pady=(8, 8))
        s = self.vault.settings
        vals = {}
        for key, label, lo, hi, default in (("autolock_min", "Auto-lock after inactivity (minutes, 0 = never)", 0, 240, 5),
                                            ("clip_seconds", "Clear clipboard after (seconds)", 5, 300, 20)):
            flabel(body, label)
            v = tk.IntVar(value=int(s.get(key, default)))
            tk.Spinbox(body, from_=lo, to=hi, textvariable=v, bg=PANEL2, fg=TEXT, buttonbackground=PANEL3,
                       insertbackground=GOLD, relief="flat", font=(FONT, 11), width=8,
                       highlightthickness=1, highlightbackground=LINE).pack(anchor="w")
            vals[key] = (v, lo, hi)
        remember = tk.BooleanVar(value=self.settings.data.get("remember_recent", True))
        tk.Checkbutton(body, text="Remember recently opened vaults (stored next to the app)", variable=remember,
                       bg=BG, fg=TEXT, selectcolor=PANEL2, activebackground=BG, activeforeground=GOLD_HI,
                       font=(FONT, 10), anchor="w", highlightthickness=0, bd=0).pack(fill="x", pady=(14, 0))
        wlabel(body, f"Vault file: {self.vault.path}\nPortable settings: {self.settings.path}", fg=MUTED,
               font=(FONT, 8), pady=(14, 0))

        def save():
            for k, (v, lo, hi) in vals.items():
                try:
                    s[k] = max(lo, min(hi, int(v.get())))
                except (ValueError, tk.TclError):
                    pass
            self.settings.data["remember_recent"] = bool(remember.get())
            if not remember.get():
                self.settings.data["recent"] = []
            self.settings.save()
            if self.persist("Settings saved"):
                top.destroy()

        row = tk.Frame(body, bg=BG)
        row.pack(fill="x", pady=(18, 0))
        GButton(row, "Cancel", top.destroy, "ghost").pack(side="left")
        GButton(row, "SAVE", save, "primary").pack(side="right")

    def save_as(self):
        p = filedialog.asksaveasfilename(parent=self, title="Save vault as", defaultextension=core.EXT,
                                         initialdir=str(self.vault.path.parent),
                                         initialfile=self.vault.path.name, filetypes=VAULT_TYPES)
        if not p:
            return
        try:
            self.vault.save(p)
        except Exception as e:
            messagebox.showerror(core.APP_NAME, f"Could not save:\n{e}", parent=self)
            return
        self.settings.add_recent(p)
        self.status(f"Saved as ✓  {p}  (now working on this copy)", GREEN)

    def show_secret(self, title, value, note):
        top, body = self.modal(title, 520, 320)
        tk.Label(body, text=title, bg=BG, fg=GOLD, font=(FONT_B, 12)).pack(pady=(4, 8))
        tk.Label(body, text=value, bg=PANEL2, fg=GOLD_HI, font=(MONO, 15), padx=14, pady=10).pack()
        wlabel(body, note, fg=MUTED, font=(FONT, 9), pady=10).config(justify="center", anchor="center")
        row = tk.Frame(body, bg=BG)
        row.pack()
        GButton(row, "Copy", lambda: self.copy(value, "Password"), "ghost").pack(side="left", padx=4)
        GButton(row, "I've saved it", top.destroy, "primary").pack(side="left", padx=4)


def main():
    if WIN:
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    App(sys.argv[1] if len(sys.argv) > 1 else None).mainloop()


if __name__ == "__main__":
    main()
